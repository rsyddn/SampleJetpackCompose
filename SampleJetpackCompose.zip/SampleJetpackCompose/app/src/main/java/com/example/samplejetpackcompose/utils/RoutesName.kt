package com.example.samplejetpackcompose.utils

object RoutesName {
    const val ONBOARDING = "Onboarding"
    const val HOME = "Home"
}