package com.example.samplejetpackcompose.utils

object Constants {
    const val BASE_URL = "https://reqres.in/api/"
}