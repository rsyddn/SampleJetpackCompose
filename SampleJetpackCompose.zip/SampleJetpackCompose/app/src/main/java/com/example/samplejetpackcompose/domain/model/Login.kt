package com.example.samplejetpackcompose.domain.model

data class Login(
    val token: String = ""
)